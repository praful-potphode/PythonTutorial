from src.object_repository.page_objects import page_objects
import time
class HomePage():
    def __init__(self, driver,url,usernamelocator,passwordlocator,signinlocator):
        self.driver = driver
        self.driver.get(url)
        self.username=driver.find_element_by_name(page_objects.username)
        self.password = driver.find_element_by_name(page_objects.password)
        self.submit = driver.find_element_by_name(page_objects.signin)
    def login(self,username,password):
        self.username.send_keys(username)
        self.password.send_keys(password)
        time.sleep(5)
        self.submit.click()