import unittest


class baseclass(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        print("------setUpClass executes only once. ")
        # print

    def setUp(self):
        print("---setUp executes before every test method!")

    def tearDown(self):
        print("---tearDown executes after every test method!")

    @classmethod
    def tearDownClass(cls):
        # print
        print("------tearDownClass executes only once.")