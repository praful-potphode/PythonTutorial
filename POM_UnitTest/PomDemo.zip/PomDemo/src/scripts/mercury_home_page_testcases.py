from src.scripts.baseclass import baseclass
from src.pages.mercury_home import HomePage
from selenium import webdriver
import unittest
import traceback
def setUpModule():
    print("---------setUpModule executes only once. ")

def tearDownModule():
    print("---------setUpModule executes only once. ")
class home_page_suite(baseclass):

    def testlogin(self):
        try:
            browser = webdriver.Chrome()
            page=HomePage(browser,'http://newtours.demoaut.com/','','','')
            page.login('mercury','mercury')
        except Exception:
            print('Exception Occured')
            print(traceback.format_exc())
    # def main(self):
    #     browser = webdriver.Chrome()
    #     page = HomePage(browser, '', '', '')
    #     page.login()

if __name__ == '__main__':

    unittest.main(verbosity=2)
