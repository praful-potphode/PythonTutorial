class page_objects:
    username="userName"
    password="password"
    signin="login"