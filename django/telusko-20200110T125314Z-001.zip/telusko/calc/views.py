from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def home(request):
    return render(request,'home.html',{'name':'Praful'})

def add(request):
    if request.method=='POST':
        number1=int(request.POST['number1'])
        number2 = int(request.POST['number2'])
        add_numbers=number1+number2
        return render(request, 'add.html', {'add_numbers': add_numbers})
    else:
        return render(request, 'add.html')
def multiply(request):
    if request.method=='POST':
        number1=int(request.POST['number1'])
        number2 = int(request.POST['number2'])
        multiply_numbers=number1*number2
        return render(request, 'multiply.html', {'multiply_numbers': multiply_numbers})
    else:
        return render(request, 'multiply.html')
def divide(request):
    if request.method=='POST':
        number1=int(request.POST['number1'])
        number2 = int(request.POST['number2'])
        divide_numbers=number1/number2
        return render(request, 'divide.html', {'divide_numbers': divide_numbers})
    else:
        return render(request, 'divide.html')